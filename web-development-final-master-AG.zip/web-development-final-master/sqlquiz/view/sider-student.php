<?php
/**
 * Created by PhpStorm.
 * User: zhangruoqiu
 * Date: 2017/6/28
 * Time: 下午5:42
 */
?>

<div class="col-sm-3 col-md-2 sidebar">
    <ul class="nav nav-sidebar">
        <li ><a href="student.php">My Evaluations</a></li>
        <li><a href="">Profile</a></li>
    </ul>
</div>
