<?php
/**
 * Created by PhpStorm.
 * User: zhangruoqiu
 * Date: 2017/6/28
 * Time: 下午5:42
 */
?>

<div class="col-sm-3 col-md-2 sidebar">
    <ul class="nav nav-sidebar">
        <li><a href="course.php">Courses</a></li>
        <li ><a href="trainer_quiz.php">My Quizzes</a></li>
       
    </ul>
</div>
